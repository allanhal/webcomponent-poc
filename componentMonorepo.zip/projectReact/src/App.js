import "./App.css";

export default function App() {
  return <railz-component first="first" middle="middle" last="last" />;
}
